import React, { Fragment } from "react";

const HeaderMenu = () => {
  return (
    <Fragment>
      <nav>
        <ul>
          <li>
            <a href="">Premium</a>
          </li>
          <li>
            <a href="">Support</a>
          </li>
          <li>
            <a href="">Download</a>
          </li>
          <li className="bar">
            <a href=""></a>
          </li>
          <li>
            <a href="">Sign up</a>
          </li>
          <li>
            <a href="">Log in</a>
          </li>
        </ul>
      </nav>
    </Fragment>
  );
};

export default HeaderMenu;
