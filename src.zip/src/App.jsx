import React from "react";
import Navbar from "./Pages/HeaderComponent/Navbar";
import "./index.css";
const App = () => {
  return (
    <section>
      <article>
        <Navbar />
      </article>
    </section>
  );
};

export default App;
